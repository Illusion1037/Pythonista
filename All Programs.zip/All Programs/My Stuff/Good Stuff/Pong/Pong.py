from scene import *
import sys
class MyScene (Scene):
	def setup(self):
		self.layer = Layer(Rect(self.size.w * 0.5 - 100, 50, 100, 10))
		self.layer.background = Color(0, 0, 1)
		# self.layer.animate('alpha', 0.0, duration=1.0, autoreverse=True, repeat=sys.maxint)
	def draw(self):
		background(1, 1, 1)
		self.layer.update(self.dt)
		self.layer.draw()
	def touch_began(self, touch):
		new_frame = Rect(touch.location.x - 50, 50, 100, 10)
		self.layer.animate('frame', new_frame, duration=2.0, curve=curve_bounce_out)
run(MyScene())



