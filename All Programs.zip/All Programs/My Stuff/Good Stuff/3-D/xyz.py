from scene import *
from math import sin, cos

class World (object):
	def __init__(self, tileimg='', tileclr=(0, 0, 0), tilebrdr=(1, 1, 1), width=10, length=10):
		self.width = width
		self.length = length
		
		self.tileimg = tileimg
		self.tileclr = tileclr
		self.tilebrdr = tilebrdr
		
		self.cx = self.cy = self.cz = self.ox = self.oy = self.oz = self.vx = self.vy = self.vz = 0
		
	def draw(self):
		dx = cos(self.oy) * ((sin(self.oz) * (self.ay - self.cy)) + (cos(self.oz) * (self.ax - self.cx))) - sin(self.oy) * (self.az - self.cz)
