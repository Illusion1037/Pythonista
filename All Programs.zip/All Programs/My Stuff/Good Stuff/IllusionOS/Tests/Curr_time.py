from datetime import datetime

def curr_time():
			timelist = str(datetime.now()).split()
			time = timelist[1]
			
			hour = int(time[0:2])
			min = int(time[3:5])
			sec = int(time[6:8])
			
			if hour > 12:
				hour -= 12
				
			if hour < 10:
				hour = '0' + str(hour)
			else:
				hour = str(hour)
			
			if min < 10:
				min = '0' + str(min)
			else:
				min = str(min)
			
			if sec < 10:
				sec = '0' + str(sec)
			else:
				sec = str(sec)
				
			timelist = [hour, min, sec]
			return timelist
			
print(curr_time())
