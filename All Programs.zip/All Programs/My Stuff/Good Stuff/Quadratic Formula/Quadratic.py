# coding: utf-8

import ui
from cmath import sqrt

def go(sender):
	a = float(v['a'].text)
	b = float(v['b'].text)
	c = float(v['c'].text)
	
	x1 = ((b * -1) + (b ** 2 - sqrt(4 * a * c))) / (2 * a)
	x2 = ((b * -1) - (b ** 2 - sqrt(4 * a * c))) / (2 * a)
	
	ans = v['quadratic formula']
	ans.text = 'x = ' + str(x1) + ', ' + str(x2)

v = ui.load_view('Quadratic')
v.present()
