import ui

v = ui.load_view('TeardropOS')
v.present(orientations=['portrait'])

def onclick(sender):
	if sender.title == 'home':
		gohome()

def gohome():
	global v
	
	btn1 = v['button1']
	btn1.image = 'ionicons-clock'
	btn2 = v['button2']
	btn2.image = 'ionicons-calculator'
	btn3 = v['button3']
	btn3.image = 'ionicons-document-text'
	btn4 = v['button4']
	btn4.image = 'ionicons-game-controller-a'
	btn5 = v['button5']
	btn5.image = 'ionicons-gear-a'
	btn6 = v['button6']
	btn6.image = 'ionicons-mic-a'
	btn7 = v['button7']
	btn7.image = 'ionicons-music-note'
	btn8 = v['button8']
	btn8.image = 'ionicons-email'
	
	txtfld = v['textfield']
	txtfld.placeholder = 'Login'
