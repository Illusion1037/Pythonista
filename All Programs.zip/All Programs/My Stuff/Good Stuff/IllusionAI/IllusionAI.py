# coding: utf-8

import ui
import speech

name = ''
say = 1
specResponce = 0

def button_clicked(sender):
	global name, say, specResponce
	
	if sender.name == 'go' and specResponce == 0:
		textfield = v['input']
		question = textfield.text
		question = question.lower()
		textview = v['Text']
		textfield.end_editing()
		
		if question == 'what is your name' or question == 'what is your name?':
			textview.text = 'My name is Illusion.\nWhat\'s yours?'
			speech.say(textview.text, 'en-US', 0.2)
			say = 0
			textfield.begin_editing()
			textfield.text = ''
			specResponce = 'name'
			
			
		elif question == 'what can you do' or question == 'what can you do?' and specResponce == 0:
			textview.text = 'I can add to a calendar, and notify you whenever you want.'
			say = 1
			
		elif question == 'hi' or question == 'hello' and specResponce == 0:
			if name == '':
				textview.text = 'Hi there'
			else:
				textview.text = 'Hi, ' + name
			say = 1
		
		elif specResponce == 'name':
			name = textfield.text
			say = 1
			textview.text = 'Hi, ' + name
			specResponce =  0
		
		else:
			textview.text = 'I don\'t understand'
		
		if say == 1:
			speech.say(textview.text, 'en-US', 0.2)

v = ui.load_view('IllusionAI')
v.present('sheet')
