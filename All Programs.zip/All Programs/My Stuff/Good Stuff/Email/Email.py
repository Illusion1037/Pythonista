import smtplib
from email.mime.text import MIMEText

my_email = raw_input('Insert your email ')
my_password = raw_input('Insert your password ')
subject = raw_input('Insert the subject ')
destination = raw_input('Insert the destination email ')
text = raw_input('Insert the message ')

msg = MIMEText(text)

msg['Subject'] = subject
msg['From'] = my_email
msg['Reply-To'] = my_email
msg['To'] = destination

server = smtplib.SMTP('smtp.gmail.com', 465)
server.starttls()
server.login(my_email, my_password)
server.sendmail(my_email, destination, msg.as_string())
server.quit()

print('Your email has been sent!')
