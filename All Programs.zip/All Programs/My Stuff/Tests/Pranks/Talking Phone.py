# coding: utf-8

import ui
import speech

def click(sender):
	if sender.name == 'say':
		text = v['textfield'].text
		speech.say(text, 'en-US', 0.3)
		text = ''
		
v = ui.load_view('Talking Phone')
v.present('sheet')
