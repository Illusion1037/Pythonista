# coding: utf-8

import ui

def button_clicked(sender):
	if sender.name == 'button':
		sender.background_color = '#000'
		v['bg'].background_color = '#000'

v = ui.load_view('Blank Screen')
v.present(orientations=['portrait'])
