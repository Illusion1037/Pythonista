# -------------------------
# File Editor
# Allows you to read and
# edit plaintext files
# File Editor.py
# -------------------------

fileName = ''
mode = ''

def repeat(func,var,value,ifFunc):
	while var != value:
		func
		if var != value:
			ifFunc

run = input('Continue? ')

while run.lower() == 'yes':
	repeat(fileName = input('Enter the filename: '),fileName[-4:],'.txt',print('Invalid Filename: Filename must end with \'.txt\'\n'))
	repeat(mode = input('Enter mode: read or edit '),mode.lower(),('read' or 'edit'),print('Invalid Mode: Must be \'read\' or \'edit\'\n')
	if mode.lower() == 'read':
		mode = 'r'
	else:
		mode = 'w'
	
	f = open(fileName,mode)
	
	if mode.lower() == 'read':
		for line in f:
			print(line)
		
		line = input('Press enter to continue')
	else:
		while line != 'close':
			file += input() + '\n'
		save = input('Do you want to save? ')
		if save.lower() == 'yes':
			f.write(file)
			print('Changes saved')
		else:
			newFile = input('Do you want to save your changes to a new file? ')
			if newFile.lower() == 'yes':
				newName = input('What will this file\'s name be? ')
				newF = open(fileName,'w')
				newF.write(file)
				newF.close()
				print('Changes saved')
			else:
				file = ''
				print('Changes lost')
	f.close()
	run = input('Continue? ')
