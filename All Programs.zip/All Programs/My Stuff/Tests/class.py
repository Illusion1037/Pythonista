import Class

class test (Class.B):
	def print_hi(self):
		print(self.hi)
		
		for num in range(10):
			print num + 1
		
Class.run(test())
