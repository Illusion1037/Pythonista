import SimpleUI

sui = SimpleUI

sui.init_ui()

sui.display('SimpleUI Test')
