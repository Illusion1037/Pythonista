f = open('MyFile.txt','w')
f.write('How are you?\nI am fine.')
f.close()
f = open('MyFile.txt','r')
for line in f:
	print(line)
f.close()
