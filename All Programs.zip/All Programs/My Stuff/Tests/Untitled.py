from scene import *

xValues = []
yValues = []

class MyScene (Scene):
	def setup(self):

		pass
	def draw(self):
		# This will be called for every frame (typically 60 times per second).
		background(0, 0, 0)
		# Draw a red circle for every finger that touches the screen:
		fill(1, 0, 0)
		for touch in self.touches.values():
			xValues.append(touch.location.x)
			yValues.append(touch.location.y)
			ellipse(xValues[int(value)] - 50, yValues[int(value)] - 50, 10, 10)
	
	def touch_began(self, touch):
		pass
	
	def touch_moved(self, touch):
		pass

	def touch_ended(self, touch):
		pass

run(MyScene())
