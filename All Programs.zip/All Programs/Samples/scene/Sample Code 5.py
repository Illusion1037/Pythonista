from scene import *
class MyScene (Scene):
	def draw (self):
		background(0, 0, 0)
		fill(1, 0, 0)
		for touch in self.touches.values():
			location = touch.location
			ellipse(location.x - 50, location.y - 50, 100, 100)
run(MyScene())
