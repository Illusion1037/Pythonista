from scene import *
class MyScene (Scene):
	def draw(self):
		push_matrix()
		rotate(20)
		scale(2, 1)
		background(0, 0, 0.35)
		fill(0, 0, 1)
		w, h = self.size.w, self.size.h
		rect(w * 0.5 - 100, h * 0.5 - 100, 200, 200)
		pop_matrix()
		rect(20, 20, 20, 20)
run(MyScene())
