# Motion control demo
from scene import *
class MyScene (Scene):
	def setup(self):
		self.x = self.size.w * 0.5
		self.y = self.size.h * 0.5
	def draw(self):
		background(0, 1, 3)
		fill(0, 0, 0.35)
		g = gravity()
		self.x += g.x * 10
		self.y += g.y * 10
		self.x = min(self.size.w - 100, max(0, self.x))
		self.y = min(self.size.h - 100, max(0, self.y))
		rect(self.x, self.y, 100, 100)
run(MyScene())
