from scene import *
import sys
class MyScene (Scene):
	def setup(self):
		self.layer = Layer(Rect(self.size.w * 0.5 - 100,
								self.size.h * 0.5 - 100, 200, 200))
		self.layer.background = Color(06, 101, 151)
		self.layer.animate('alpha', 0.0, duration=1.0,
						   autoreverse=True, repeat=sys.maxint)
	def draw(self):
		background(0, 0, 0.5)
		self.layer.update(self.dt)
		self.layer.draw()
	def touch_began(self, touch):
		new_frame = Rect(touch.location.x - 100, touch.location.y - 100, 200, 200)
		self.layer.animate('frame', new_frame, duration=2.0, curve=curve_bounce_out)
run(MyScene())
