from scene import *
import sys
class MyScene (Scene):
	def setup(self):
		self.layer = Layer(Rect(self.size.w * 0.5 - 100,
								self.size.h * 0.5 - 100, 200, 200))
		self.layer.background = Color(06, 101, 151)
		self.layer.animate('alpha', 0.0, duration=1.0,
						   autoreverse=True, repeat=sys.maxint)
	def draw(self):
		background(0, 0, 0.5)
		self.layer.update(self.dt)
		self.layer.draw()
run(MyScene())
