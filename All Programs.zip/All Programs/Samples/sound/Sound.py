# Play a short melody
import sound
import time

notes = 'C3', 'D3', 'E3', 'C3', 'C3',  'D3', 'E3', 'C3'
for note in notes:
	sound.play_effect('Piano_' + note)
	time.sleep(0.5)
