import ui

def real(num):
	num *= 10
	return num
	
def rect(x, y):
	 ui.Path.rect(real(x), real(y), 10, 10).fill()

with ui.ImageContext(300, 100) as ctx:
	ui.set_color('white')
	ui.fill_rect(0, 0, 300, 100)
	ui.set_color('black')
	rect = ui.Path.rect(10, 10, 80, 80)
	rect.fill()
	ui.set_color('#069BEB')
	rect(3, 3)
	img = ctx.get_image()
	img.show()
