from scene import *
import button

def start(app):
	run(app)

class App (Scene):
	
	def __init__(self):
		self.pages = []
		self.curr_page = None
		
	def add_page(self, page):
		self.pages.append(page)
		self.curr_page = page
	
	def set_page(self, page):
		if page in self.pages:
			self.curr_page = page
	
	def setup(self):
		self.curr_page.init()
	
	def draw(self):
		self.curr_page.draw()

class Page (object):
	def __init__(self, title='New Page', color=(0, 0, 0), txtcolor=(1, 1, 1), bgcolor=(1, 1, 1), header=True):
		self.title = title
		self.color = color
		self.txtcolor = txtcolor
		self.bgcolor = bgcolor
		self.header = header
		
	def set_title(self, title):
		self.title = title
		
	def set_color(self, color):
		self.color = color
		
	def set_bgcolor(self, bgcolor):
		self.bgcolor = bgcolor
	
	def set_txtcolor(self, txtcolor):
		self.txtcolor = txtcolor
		
	def set_header(self, title, color, txtcolor):
		self.title = title
		self.color = color
		self.txtcolor = txtcolor
	
	def toggle_header(self):
		if self.header:
			self.header = False
		else:
			self.header = True
			
	def init(self):
		try:
			self.setu()
		except AttributeError:
			pass
		
	def draw(self):
		background(self.bgcolor[0], self.bgcolor[1], self.bgcolor[2])
		try:
			self.main()
		except AttributeError:
			pass
		
		if self.header:
			fill(self.color[0], self.color[1], self.color[2])
			rect(0, 440, 320, 40)
			tint(self.txtcolor[0], self.txtcolor[1], self.txtcolor[2])
			text(str(self.title), 'AvenirNext-Regular', 24, 160, 460, 5)
			fill(0.60, 0.60, 0.60, 0.60)
			rect(0, 439.5, 320, 0.5)
			fill(0.5, 0.5, 0.5, 0.5)
			rect(0, 439, 320, 0.5)
			fill(0.4, 0.4, 0.4, 0.4)
			rect(0, 438.5, 320, 0.5)
			fill(0.3, 0.3, 0.3, 0.3)
			rect(0, 438, 320, 0.5)
			fill(0.2, 0.2, 0.2, 0.2)
			rect(0, 437.5, 320, 0.5)
			fill(0.1, 0.1, 0.1, 0.1)
			rect(0, 437, 320, 0.5)
