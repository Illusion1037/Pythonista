from scene import *

class TextButton (object):
	def __init__(self, text, rect, font='AvenirNext-Regular', fontsize=16, color=(0.7, 0.7, 0.7), altcolor=(0.4, 0.4, 0.4), txtcolor=(0, 0, 0), alttxtcolor=(1, 1, 1)):
		self.x = rect[0]
		self.y = rect[1]
		self.w = rect[2]
		self.h = rect[3]
		
		self.text = text
		self.font = font
		self.fontsize = fontsize
		
		self.color = color
		self.altcolor = altcolor
		self.txtcolor = txtcolor
		self.alttxtcolor = alttxtcolor
		
		self.touch = None
		
	def draw(self, touches):
		for touch in touches:
			if Rect(touch.location[0], touch.location[1], 1, 1) in Rect(self.x, self.y, self.w, self.h):
				try:
					self.onclick()
				except AttributeError:
					pass
				self.touch = touch
				
		
		if not self.touch in touches:
			try:
				self.onrelease()
			except AttributeError:
				pass
			self.touch = None
		
		if self.touch == None:
			fill(self.color[0], self.color[1], self.color[2])
			tint(self.txtcolor[0], self.txtcolor[1], self.txtcolor[2])
			rect(self.x, self.y, self.w, self.h)
			text(self.text, self.font, self.fontsize, self.x + (self.w / 2), self.y + (self.h / 2))
		else:
			fill(self.color[0], self.color[1], self.color[2])
			tint(self.txtcolor[0], self.txtcolor[1], self.txtcolor[2])
			rect(self.x, self.y, self.w, self.h)
			text(self.text, self.font, self.fontsize, self.x + (self.w / 2), self.y + (self.h / 2))
		
